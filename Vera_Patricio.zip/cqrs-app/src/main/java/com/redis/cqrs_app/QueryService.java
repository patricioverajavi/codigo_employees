package com.redis.cqrs_app;

import redis.clients.jedis.Jedis;

public class QueryService {

    public String obtenerEmpleado(String empNo) {
        try (Jedis jedis = new Jedis("localhost", 6379)) {
            // Redis guardó la data con el formato que definimos en el Sincronizador
            String datos = jedis.get("empleado:" + empNo);
            
            return (datos != null) ? datos : "Empleado no encontrado en Redis.";
        } catch (Exception e) {
            return "Error de conexión: " + e.getMessage();
        }
    }
}