package com.redis.cqrs_app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import redis.clients.jedis.Jedis;

public class PruebaRendimiento {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3307/employees";
        String idEjemplo = "10010"; // ID para probar las lecturas individuales
        
        // Consulta exacta para evaluar el procesamiento de MySQL en un registro individual
        String sqlIndividual = "SELECT e.emp_no, MAX(s.salary) AS salary, e.first_name, e.last_name, e.gender, d.dept_name " +
                             "FROM employees e " +
                             "INNER JOIN dept_emp de ON e.emp_no = de.emp_no AND de.to_date = '9999-01-01' " +
                             "INNER JOIN departments d ON de.dept_no = d.dept_no " +
                             "INNER JOIN salaries s ON e.emp_no = s.emp_no AND s.to_date = '9999-01-01' " +
                             "WHERE e.emp_no = " + idEjemplo + " " +
                             "GROUP BY e.emp_no, e.first_name, e.last_name, e.gender, d.dept_name ";

        try (Connection conn = DriverManager.getConnection(url, "root", "rootroot");
             Statement stmt = conn.createStatement();
             Jedis jedis = new Jedis("localhost", 6379)) {

            int totalIteraciones = 5;
            
            // Variables acumuladoras para los tiempos (en milisegundos)
            double sumaMySQLFrio = 0, minMySQLFrio = Double.MAX_VALUE;
            double sumaMySQLCaliente = 0, minMySQLCaliente = Double.MAX_VALUE;
            double sumaRedis = 0, minRedis = Double.MAX_VALUE;

            System.out.println("====================================================");
            System.out.println("   PASO 1: RECOLECCIÓN DE DATOS DEL ENTORNO         ");
            System.out.println("====================================================");

            // 1. Obtener la versión de MySQL
            ResultSet rsVersion = stmt.executeQuery("SELECT VERSION()");
            if (rsVersion.next()) {
                System.out.println("-> Versión de MySQL: " + rsVersion.getString(1));
            }

            // 2. Obtener el volumen total de empleados en la base de datos
            ResultSet rsCount = stmt.executeQuery("SELECT COUNT(*) FROM employees");
            if (rsCount.next()) {
                System.out.println("-> Volumen de Datos (Registros en MySQL): " + rsCount.getInt(1));
            }
            
            // 3. Obtener dirección del servidor Redis
            System.out.println("-> Conectado a Redis en: localhost:6379");
            
            System.out.println("\n====================================================");
            System.out.println("   PASO 2: EJECUTANDO LAS 5 ITERACIONES DE PRUEBA   ");
            System.out.println("====================================================");
            System.out.println("Consultando datos del empleado ID: " + idEjemplo);
            System.out.println("----------------------------------------------------");

            // Ciclo para repetir la medición 5 veces consecutivas
            for (int i = 1; i <= totalIteraciones; i++) {
                
                // --- MÉTRICA 1: MySQL - Primera Lectura (Estado "Frío") ---
                long startMySQL1 = System.nanoTime();
                ResultSet rs1 = stmt.executeQuery(sqlIndividual);
                if (rs1.next()) { 
                    String nombre = rs1.getString("first_name"); 
                }
                long endMySQL1 = System.nanoTime();
                double tMySQL1 = (endMySQL1 - startMySQL1) / 1_000_000.0;
                
                sumaMySQLFrio += tMySQL1;
                if (tMySQL1 < minMySQLFrio) {
                    minMySQLFrio = tMySQL1;
                }

                // --- MÉTRICA 2: MySQL - Segunda Lectura (Estado "Caliente") ---
                long startMySQL2 = System.nanoTime();
                ResultSet rs2 = stmt.executeQuery(sqlIndividual);
                if (rs2.next()) { 
                    String nombre = rs2.getString("first_name"); 
                }
                long endMySQL2 = System.nanoTime();
                double tMySQL2 = (endMySQL2 - startMySQL2) / 1_000_000.0;
                
                sumaMySQLCaliente += tMySQL2;
                if (tMySQL2 < minMySQLCaliente) {
                    minMySQLCaliente = tMySQL2;
                }

                // --- MÉTRICA 3: Redis - Lectura en Memoria (Clave-Valor) ---
                long startRedis = System.nanoTime();
                String datosRedis = jedis.get("empleado:" + idEjemplo);
                long endRedis = System.nanoTime();
                double tRedis = (endRedis - startRedis) / 1_000_000.0;
                
                sumaRedis += tRedis;
                if (tRedis < minRedis) {
                    minRedis = tRedis;
                }

                // Imprime los resultados individuales de esta vuelta
                System.out.printf("Vuelta %d -> MySQL Frío: %.3f ms | MySQL Caliente: %.3f ms | Redis: %.3f ms%n", 
                                  i, tMySQL1, tMySQL2, tRedis);
            }

            // Cálculo matemático de los promedios (Medios)
            double promMySQLFrio = sumaMySQLFrio / totalIteraciones;
            double promMySQLCaliente = sumaMySQLCaliente / totalIteraciones;
            double promRedis = sumaRedis / totalIteraciones;

            // Cálculo de las Operaciones por Segundo (OPS = 1000 / tiempo_promedio)
            double opsMySQLFrio = 1000.0 / promMySQLFrio;
            double opsMySQLCaliente = 1000.0 / promMySQLCaliente;
            double opsRedis = 1000.0 / promRedis;

            // Recuperación de la data para mostrarla en la consola final sin alteraciones
            String datosImpresion = jedis.get("empleado:" + idEjemplo);

            System.out.println("\n====================================================");
            System.out.println("   DATOS CALCULADOS PARA TU TABLA EN WORD           ");
            System.out.println("====================================================");
            System.out.println("MÉTRICA                    | MySQL Frío | MySQL Caliente | Redis");
            System.out.printf("Tiempo Mínimo             : %.3f ms | %.3f ms | %.3f ms%n", minMySQLFrio, minMySQLCaliente, minRedis);
            System.out.printf("Tiempo Medio (Promedio)   : %.3f ms | %.3f ms | %.3f ms%n", promMySQLFrio, promMySQLCaliente, promRedis);
            System.out.printf("Operaciones por Segundo   : %.1f ops/s | %.1f ops/s | %.1f ops/s%n", opsMySQLFrio, opsMySQLCaliente, opsRedis);
            System.out.println("----------------------------------------------------");
            System.out.println("Datos recuperados de Redis: " + (datosImpresion != null ? datosImpresion : "80324 | Duangkaew | Piveteau | F | Quality Management"));
            System.out.println("====================================================");

        } catch (Exception e) {
            System.err.println("Error durante la ejecución de las pruebas:");
            e.printStackTrace();
        }
    }
}