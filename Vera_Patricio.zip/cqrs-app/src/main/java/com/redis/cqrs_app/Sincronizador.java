package com.redis.cqrs_app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import redis.clients.jedis.Jedis;

public class Sincronizador {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3307/employees";
        
        String sql = "SELECT e.emp_no, MAX(s.salary) AS salary, e.first_name, e.last_name, e.gender, d.dept_name " +
                     "FROM employees e " +
                     "INNER JOIN dept_emp de ON e.emp_no = de.emp_no AND de.to_date = '9999-01-01' " +
                     "INNER JOIN departments d ON de.dept_no = d.dept_no " +
                     "INNER JOIN salaries s ON e.emp_no = s.emp_no AND s.to_date = '9999-01-01' " +
                     "GROUP BY e.emp_no, e.first_name, e.last_name, e.gender, d.dept_name ";

        System.out.println("Iniciando sincronización ...");

        // 1. CAPTURAMOS EL TIEMPO DE INICIO
        long startTime = System.currentTimeMillis();

        try (Connection conn = DriverManager.getConnection(url, "root", "rootroot");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql);
             Jedis jedis = new Jedis("localhost", 6379)) { 

            int count = 0;
            while (rs.next()) {
                String empId = rs.getString("emp_no");
                String data = rs.getString("salary") + " | " + 
                              rs.getString("first_name") + " | " + 
                              rs.getString("last_name") + " | " + 
                              rs.getString("gender") + " | " + 
                              rs.getString("dept_name");
                
                jedis.set("empleado:" + empId, data);
                count++;
            }

            // 2. CAPTURAMOS EL TIEMPO FINAL Y CALCULAMOS
            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;

            System.out.println("Sincronización exitosa. Registros procesados: " + count);
            System.out.println("Tiempo total de ejecución: " + duration + " ms (" + (duration / 1000.0) + " segundos)");

        } catch (Exception e) {
            System.err.println("Error en la sincronización:");
            e.printStackTrace();
        }
    }
}