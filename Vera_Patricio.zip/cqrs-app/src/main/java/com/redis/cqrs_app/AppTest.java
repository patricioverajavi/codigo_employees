package com.redis.cqrs_app;

public class AppTest {
    public static void main(String[] args) {
        QueryService service = new QueryService();
        String idEjemplo = "10010";
        
        System.out.println("--- PRUEBA DE CONSULTA CQRS ---");
        System.out.println("Consultando ID: " + idEjemplo);
        
        // 1. CAPTURAMOS EL TIEMPO EN NANOSEGUNDOS ANTES DE LA CONSULTA
        long startTime = System.nanoTime();
        
        String resultado = service.obtenerEmpleado(idEjemplo);
        
        // 2. CAPTURAMOS EL TIEMPO FINAL
        long endTime = System.nanoTime();
        
        // 3. CALCULAMOS LA DIFERENCIA (Dividido entre 1,000,000 para pasarlo a milisegundos)
        double durationMs = (endTime - startTime) / 1_000_000.0;
        
        System.out.println("Datos: " + resultado);
        System.out.println("-------------------------------");
        System.out.printf("Tiempo de respuesta de Redis: %.3f ms %n", durationMs);
        System.out.println("-------------------------------");
    }
}